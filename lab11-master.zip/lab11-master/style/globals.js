/* styles/globals.css */
html, body, #__next {
  height: 100%;
}
body {
  margin: 0;
  font-family: Inter, Arial, sans-serif;
  background: #fafafa;
  color: #222;
  line-height: 1.5;
}
a { color: #0070f3; text-decoration: none; }
